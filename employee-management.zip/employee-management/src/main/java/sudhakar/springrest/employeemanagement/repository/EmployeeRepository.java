package sudhakar.springrest.employeemanagement.repository;

import java.util.List;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;

import sudhakar.springrest.employeemanagement.model.Employee;

import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>{

//List<Employee> sortByFirstNameAsc(String firstname);

//List<Employee> sortByFirstNameAsc();

//@Query("FROM #{#Employee} WHERE firstName = ?1")
//   List<Employee> findByFirstName(String firstName);
//	List<Employee> findByFirstNameAsc();
//	List<Employee> findByFirstNameContaining(String firstName);
}
