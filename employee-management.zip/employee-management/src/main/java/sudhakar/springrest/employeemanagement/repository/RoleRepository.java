package sudhakar.springrest.employeemanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sudhakar.springrest.employeemanagement.model.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {

}
