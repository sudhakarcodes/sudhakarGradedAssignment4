package sudhakar.springrest.employeemanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sudhakar.springrest.employeemanagement.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
	public User findByUsername(String username);
}
